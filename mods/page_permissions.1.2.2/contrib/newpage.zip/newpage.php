<?php

// Blank phpBB page created to be used as a tutorial
// for adding a new php page to your phpBB forum
// environment. The latest version of this file
// and the associated template (which includes
// the content of the tutorial) can be downloaded
// from www.phpbbdoctor.com and is included as 
// bonus material in the Page Permissions MOD.
// � www.phpBBDoctor.com

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

$page_title = 'New Page Title';

include($phpbb_root_path . 'includes/page_header.'.$phpEx);

$template->set_filenames(array(
        'body' => 'newpage_body.tpl'
        ));

$template->pparse('body');

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>