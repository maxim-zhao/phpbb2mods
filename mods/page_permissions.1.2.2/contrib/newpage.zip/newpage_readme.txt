This is a new page "template" that you can use to add additional content
to your phpBB board. You can then protect access to these new pages using
the Page Permissions MOD. You can view this page online at:

http://www.phpbbdoctor.com/newpage.php

Copy newpage.php to your forum root
Copy newpage_body.tpl to your template folder
Go to www.yourdomain.com/forumpath/newpage.php to review the instructions

Note that as provided the "newpage.php" page will use PAGE_INDEX as
the page constant. This is so you can open / read the instructions prior
to making any changes to the files. If you use this page as a template
for new pages, be sure to follow the instructions as provided on the
page itself.